#!/usr/bin/bash

printf "This program is: test.sh\n"

printf "Today is Tuesday 14 October 2025\n"

exit

