sum=0
for num in "$@"; do
	sum=$((sum+num))
done

printf "$sum\n"

