#!/bin/bash

for i in $(seq 1 $1)
do
  seq -s '' 1 $i
done
