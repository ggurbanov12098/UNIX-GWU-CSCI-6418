Farenheit to Celcius task
::::: 55 F = 12 C






show the exact line (input argument as a line number) in the text document, if the input number is larger than the existing number of lines in a text file...
don't let the script file crash, handle it with file exception if possible (doesn't matter how)

extension to the program is you can show the range of number of lines like:
user@Ubuntu>> ./lines_range_file.sh 55 59 ymanls.txt

and this command should show all the text lines between 55 and 59

 




another task:
dollar_change.sh
calculate what's the minimum dispense of coins like (quarter, dime, nickel, pennies)
