#!/bin/bash
set -euo pipefail

paths=("$@"); [ ${#paths[@]} -eq 0 ] && paths=(.)

tmp=$(mktemp)
cleanup(){ rm -f "$tmp"; }
trap cleanup EXIT

for p in "${paths[@]}"; do

  if [ -d "$p" ]; then
    base=$(cd "$p" 2>/dev/null && pwd)
  else
    echo "Not a directory: $p" >&2
    continue
  fi

  while IFS= read -r -d '' name; do
    full="$base/$name"
    size=$(du -sh -- "$full" 2>/dev/null | cut -f1)
    [ -z "${size:-}" ] && size="?"
    kind=$([ -d "$full" ] && echo "—dir—" || echo "——")

    printf "%s\t%s\t%s\n" "$size" "$kind" "$full" >>"$tmp"
  done < <(find "$base" -mindepth 1 -maxdepth 1 -printf '%P\0' 2>/dev/null)
done

[ -s "$tmp" ] || exit 0

sort -t $'\t' -k3,3 "$tmp" \
  | column -s $'\t' -t

echo "::::::::::::"

sort -t $'\t' -h -k1,1 "$tmp" \
  | column -s $'\t' -t
