#!/bin/bash
set -euo pipefail

DIR="${1:-.}"
COLOR="${2:-}"
[ -d "$DIR" ] || { echo "Not a directory: $DIR" >&2; exit 1; }

absdir="$(cd "$DIR" && pwd)"
totalsz="$(du -sh -- "$absdir" 2>/dev/null | cut -f1)"

if [ "${COLOR,,}" = "--color" ]; then
  c_dir="$(printf '\033[1;34m')"     # bold blue
  c_exe="$(printf '\033[1;32m')"     # bold green
  c_reg="$(printf '\033[0m')"        # reset (used to end)
else
  c_dir=""; c_exe=""; c_reg=""
fi

printf 'Directory : %s\n' "$absdir"
printf 'Total size: %s\n' "${totalsz:-?}"
printf 'Format    : ::: [<idx>] :::::::: <perms> <size> /// <path>\n\n'

idx=0

while IFS= read -r -d '' name; do
  entries+=("$name")
done < <(find "$absdir" -mindepth 1 -maxdepth 1 -printf '%P\0' 2>/dev/null | LC_ALL=C sort -z)

for name in "${entries[@]:-}"; do
  full="$absdir/$name"
  perms="$(stat -c '%A' -- "$full" 2>/dev/null || echo '?????????')"

  fsize="$(du -sh -- "$full" 2>/dev/null | cut -f1)"; : "${fsize:=?}"

  ((idx++))

  if [ -d "$full" ]; then
    pcolor="$c_dir"
  elif [ -x "$full" ] && [ ! -d "$full" ]; then
    pcolor="$c_exe"
  else
    pcolor="$c_reg"
  fi

  printf '::: [%3d] :::::::: %-10s %6s /// %s%s%s\n' \
    "$idx" "$perms" "$fsize" "$pcolor" "$full" "$c_reg"
done

printf '\nItems: %d\n' "$idx"
