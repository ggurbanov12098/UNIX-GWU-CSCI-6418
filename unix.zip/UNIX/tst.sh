#!/bin/bash
dir="${1:-.}"

# Validate
if [ ! -d "$dir" ]; then
  echo "Not a directory: $dir" >&2
  exit 1
fi

# list: size \t perms \t type-char \t name
list="$(
  find "$dir" -maxdepth 1 -mindepth 1 -printf '%s\t%M\t%y\t%f\n' 2>/dev/null
)"

[ -z "$list" ] && { echo "Directory is empty."; exit 0; }

to_human() {
  if command -v numfmt >/dev/null 2>&1; then
    numfmt --to=iec --suffix=B --padding=0 "$1" 2>/dev/null || echo "$1"
  else
    echo "$1"
  fi
}

kind_word() {
  case "$1" in
    f) echo "file" ;; d) echo "dir" ;; l) echo "link" ;;
    b) echo "block" ;; c) echo "char" ;; s) echo "sock" ;; p) echo "fifo" ;;
    *) echo "$1" ;;
  esac
}

print_header() { printf "%-10s %-11s %-5s %s\n" "SIZE" "PERMISSIONS" "TYPE" "NAME"; }

echo "Alphabetical (by name):"
print_header
echo "$list" | sort -t$'\t' -k4,4 \
| while IFS=$'\t' read -r size perms kind name; do
    printf "%-10s %-11s %-5s %s\n" "$(to_human "$size")" "$perms" "$(kind_word "$kind")" "$name"
  done

echo
echo "By size (descending):"
print_header
echo "$list" | sort -t$'\t' -k1,1nr \
| while IFS=$'\t' read -r size perms kind name; do
    printf "%-10s %-11s %-5s %s\n" "$(to_human "$size")" "$perms" "$(kind_word "$kind")" "$name"
  done
